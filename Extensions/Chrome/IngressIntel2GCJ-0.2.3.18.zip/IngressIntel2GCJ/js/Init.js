$.get(chrome.extension.getURL("teamplate/Ingress.html"), function (IngressHtml) {
    $.get("https://www.ingress.com/intel", function (BaseHtml) {
        var Player = BaseHtml.match(/var PLAYER = \{.+\};/g);
        var HeaderLoginInfo = BaseHtml.match(/<span class="pointer" id="header_email">.+@.+.com<\/span>&nbsp;/g);
        var EnDashboard = BaseHtml.match(/<script type="text\/javascript" src="\/jsc\/gen_dashboard_.+\.js"><\/script>/g);

        //console.log(Player);
        if (Player) {
            IngressHtml = IngressHtml.replace("__var_PLAYER_INF__", Player);
            IngressHtml = IngressHtml.replace("__Header_Login_Info__", HeaderLoginInfo);
            IngressHtml = IngressHtml.replace("__gen_dashboard__", EnDashboard);
            document.open();
            document.write(IngressHtml);
            document.close();
        }
    });
});
